package org.apache.jsp.jsps;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;

public final class Migration_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fs_005factionerror_005fnobody;
  private org.apache.jasper.runtime.TagHandlerPool _005fjspx_005ftagPool_005fs_005fif_0026_005ftest;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fs_005factionerror_005fnobody = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _005fjspx_005ftagPool_005fs_005fif_0026_005ftest = org.apache.jasper.runtime.TagHandlerPool.getTagHandlerPool(getServletConfig());
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
    _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.release();
    _005fjspx_005ftagPool_005fs_005factionerror_005fnobody.release();
    _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.release();
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("\n");
      out.write("\n");
      out.write("<html>\n");
      out.write("\t<head>\n");
      out.write("\t\t<title>Serena Migration Tool</title>\n");
      out.write("\t\t<link href=\"/css/styles.css?t=");
      if (_jspx_meth_s_005fproperty_005f0(_jspx_page_context))
        return;
      out.write("\" type=\"text/css\" rel=\"stylesheet\" />\n");
      out.write("\t\t<script type=\"text/javascript\" src=\"/javascript/json2.js?t=");
      if (_jspx_meth_s_005fproperty_005f1(_jspx_page_context))
        return;
      out.write("\"></script>\n");
      out.write("\t\t<script type=\"text/javascript\">\n");
      out.write("\t\t\tvar currentProgress = 0;\n");
      out.write("\t\t\tvar currentId = 0;\n");
      out.write("\t\t\tvar frames = 20;\n");
      out.write("\t\t\tvar framesPerSecond = 20;\n");
      out.write("\t\t\tvar firstTime = true;\n");
      out.write("\n");
      out.write("\t\t\tfunction callStop()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar url = \"/MigrationStopTaskAjax\";\n");
      out.write("\t\t\t    var request = GetXmlHttpObject();    \n");
      out.write("\t\t\t    request.open(\"POST\", url, true);    \n");
      out.write("\t\t\t    if (request.overrideMimeType)\n");
      out.write("\t\t\t        request.overrideMimeType('application/json');\n");
      out.write("\t\t\t    request.setRequestHeader('Content-Type', 'application/json');\n");
      out.write("\t\t\t    request.send(null);\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction startLinkChecker()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar url = \"/MigrationStartLinkCheckerAjax\";\n");
      out.write("\t\t\t    var request = GetXmlHttpObject();    \n");
      out.write("\t\t\t    request.open(\"POST\", url, true);    \n");
      out.write("\t\t\t    if (request.overrideMimeType)\n");
      out.write("\t\t\t        request.overrideMimeType('application/json');\n");
      out.write("\t\t\t    request.setRequestHeader('Content-Type', 'application/json');\n");
      out.write("\t\t\t    request.send(null);\n");
      out.write("\t\t\t    switchUIToLinkChecker();\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\n");
      out.write("\t\t\tfunction restartMigration()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar url = \"/MigrationRestartMigrationAjax\";\n");
      out.write("\t\t\t    var request = GetXmlHttpObject();    \n");
      out.write("\t\t\t    request.open(\"POST\", url, true);    \n");
      out.write("\t\t\t    if (request.overrideMimeType)\n");
      out.write("\t\t\t        request.overrideMimeType('application/json');\n");
      out.write("\t\t\t    request.setRequestHeader('Content-Type', 'application/json');\n");
      out.write("\t\t\t    request.send(null);\n");
      out.write("\t\t\t    switchUIToMigration();\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\n");
      out.write("\t\t\tfunction switchUIToLinkChecker()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tcurrentProgress = 0;\n");
      out.write("\t\t\t    document.getElementById(\"checked\").innerHTML = \"0\";\n");
      out.write("\t\t\t    document.getElementById(\"checkingErrors\").innerHTML = \"0\";\n");
      out.write("\t\t\t    document.getElementById(\"correctLinks\").innerHTML = \"0\";\n");
      out.write("\t\t\t    document.getElementById(\"brokenLinks\").innerHTML = \"0\";\n");
      out.write("\t\t\t    document.getElementById(\"migration-status\").style.display=\"none\";\n");
      out.write("\t\t\t    document.getElementById(\"link-checker-status\").style.display=\"\";\n");
      out.write("\t\t\t    window.onbeforeunload = closeEditorLinkCheckingWarning;\t\t\t    \n");
      out.write("\t\t\t    enableButtons(false, false, true, true, false, false, false);\n");
      out.write("\t\t\t    setTimeout(\"sendAjaxRequestForProgress()\", 1000);\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction switchUIToMigration()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tcurrentProgress = 0;\n");
      out.write("\t\t\t\tdocument.getElementById(\"created\").innerHTML = \"0\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"skipped\").innerHTML = \"0\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"errors\").innerHTML = \"0\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"aligned\").innerHTML = \"0\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"notAligned\").innerHTML = \"0\";\n");
      out.write("\t\t\t    document.getElementById(\"migration-status\").style.display=\"\";\n");
      out.write("\t\t\t    document.getElementById(\"link-checker-status\").style.display=\"none\";\n");
      out.write("\t\t\t    window.onbeforeunload = closeEditorMigrationWarning;\t\t\t    \n");
      out.write("\t\t\t    enableButtons(false, true, false, true, false, false, false);\n");
      out.write("\t\t\t    setTimeout(\"sendAjaxRequestForProgress()\", 1000);\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\n");
      out.write("\t\t\tfunction sendAjaxRequestForProgress()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t    var url = \"/MigrationAjax\";\n");
      out.write("\t\t\t    var request = GetXmlHttpObject();    \n");
      out.write("\t\t\t    request.open(\"POST\", url, true);    \n");
      out.write("\t\t\t    if (request.overrideMimeType)\n");
      out.write("\t\t\t        request.overrideMimeType('application/json');\n");
      out.write("\t\t\t    request.setRequestHeader('Content-Type', 'application/json');\n");
      out.write("\t\t\t    request.onreadystatechange = function () \n");
      out.write("\t\t\t    {\n");
      out.write("\t\t\t        if (request.readyState == 4) \n");
      out.write("\t\t\t        {\n");
      out.write("\t\t\t            try\n");
      out.write("\t\t\t            {\n");
      out.write("\t\t\t                if (request.status == 200) \n");
      out.write("\t\t\t                {\n");
      out.write("\t\t\t                    var response = request.responseText;                \n");
      out.write("\t\t\t    \n");
      out.write("\t\t\t                    if (response)\n");
      out.write("\t\t\t                    {\n");
      out.write("\t\t\t                    \tupdateProgressReturn(response); \n");
      out.write("\t\t\t                    }\n");
      out.write("\t\t\t                }\n");
      out.write("\t\t\t            }\n");
      out.write("\t\t\t            catch(e)\n");
      out.write("\t\t\t            {                      \n");
      out.write("\t\t\t            } \n");
      out.write("\t\t\t \n");
      out.write("\t\t\t            request = null;\n");
      out.write("\t\t\t        }\n");
      out.write("\t\t\t    };       \n");
      out.write("\t\t\t    request.send(null);\n");
      out.write("\t\t\t}\n");
      out.write("\t\n");
      out.write("\t\t\tfunction updateProgressReturn(response)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar responseObject = JSON.parse(response);\t\n");
      out.write("\t\t\t\tvar nextProgress = parseInt(responseObject[\"progress\"])/10.0;\n");
      out.write("\n");
      out.write("\t\t\t\tvar currentTask = responseObject[\"currentTask\"];\n");
      out.write("\t\t\t\tvar fullTaskName = \"\";\n");
      out.write("\t\t\t\tif (currentTask==\"migration\")\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tanimateNumber(\"created\", responseObject[\"pagesCreated\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"skipped\", responseObject[\"pagesSkipped\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"errors\", responseObject[\"pagesWithErrors\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"aligned\", responseObject[\"pagesAligned\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"notAligned\", responseObject[\"pagesNotAligned\"]);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\telse if (currentTask==\"link-checker\")\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tanimateNumber(\"checked\", responseObject[\"pagesChecked\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"checkingErrors\", responseObject[\"pagesWithErrors\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"correctLinks\", responseObject[\"correctLinks\"]);\n");
      out.write("\t\t\t\t\tanimateNumber(\"brokenLinks\", responseObject[\"brokenLinks\"]);\n");
      out.write("\t\t\t\t}\t\t\t\t\n");
      out.write("\n");
      out.write("\t\t\t\tvar log = responseObject[\"log\"];\n");
      out.write("\t\t\t\tlog = log.replace(/[\\n\\r\\t]/g,''); // Remove any new line or tab characters from the log \n");
      out.write("\t\t\t\tvar newspan = document.createElement('SPAN');\n");
      out.write("\t\t\t\tcurrentId++;\n");
      out.write("\t\t\t\tnewspan.setAttribute('id', 'span'+currentId);\n");
      out.write("\t\t\t\tdocument.getElementById(\"log\").appendChild(newspan);\n");
      out.write("\t\t\t\tanimateProgreeBar(log, nextProgress);\n");
      out.write("\t\t\t\tcurrentProgress = nextProgress;\n");
      out.write("\t\t\t\tvar completed = responseObject[\"completed\"];\n");
      out.write("\t\t\t\tif (!completed)\n");
      out.write("\t\t\t\t\tsetTimeout(\"sendAjaxRequestForProgress()\", 1000);\n");
      out.write("\t\t\t\telse\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tsetTimeout(\"completed('\"+currentTask+\"')\", 1000);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\tfirstTime = false;\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction completed(task)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar taskName = task=='migration'?\"Migration\":\"Link checking\";\n");
      out.write("\t\t\t\twindow.onbeforeunload = null;\n");
      out.write("\t\t\t\tdocument.getElementById('progress-percent').innerHTML = taskName+' completed.';\n");
      out.write("\t\t\t\tif (task=='migration')\n");
      out.write("\t\t\t\t\tenableButtons(true, false, false, true, true, false, true);\n");
      out.write("\t\t\t\telse\n");
      out.write("\t\t\t\t\tenableButtons(true, false, false, true, false, true, true);\n");
      out.write("\t\t\t}\n");
      out.write("\t\n");
      out.write("\t\t\tfunction animateProgreeBar(log, nextProgress)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tif (firstTime)\n");
      out.write("\t\t\t\t\tframes = 1;\n");
      out.write("\t\t\t\telse\n");
      out.write("\t\t\t\t\tframes = 20;\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\tfor(var i=1;i<=frames;i++)\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tvar progress = currentProgress+i*(nextProgress-currentProgress)/frames;\n");
      out.write("\t\t\t\t\tsetTimeout(\"updateProgressFrame(\"+progress+\", \"+(i*100/frames)+\", '\"+log+\"')\", i * 1000 / framesPerSecond);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction animateNumber(elId, newVal)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tif (firstTime)\n");
      out.write("\t\t\t\t\tframes = 1;\n");
      out.write("\t\t\t\telse\n");
      out.write("\t\t\t\t\tframes = 20;\n");
      out.write("\t\t\t\t\n");
      out.write("\t\t\t\tvar el = document.getElementById(elId);\n");
      out.write("\t\t\t\tvar oldVal = parseInt(el.innerHTML);\n");
      out.write("\t\t\t\tnewVal = parseInt(newVal);\n");
      out.write("\t\t\t\tfor(var i=1;i<=frames;i++)\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tvar val = oldVal+i*(newVal-oldVal)/frames;\n");
      out.write("\t\t\t\t\tsetTimeout(\"updateNumberFrame('\"+elId+\"', \"+val+\")\", i * 1000 / framesPerSecond);\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction updateNumberFrame(elId, amount)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tdocument.getElementById(elId).innerHTML = Math.round(amount);\n");
      out.write("\t\t\t}\n");
      out.write("\t\n");
      out.write("\t\t\tfunction updateProgressFrame(amount, framePercent, log)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tdocument.getElementById(\"progress-bar\").style.width=amount+\"%\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"progress-percent\").innerHTML = Math.round(amount)+\"%\";\n");
      out.write("\t\t\t\tif (log.length>0)\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\tdocument.getElementById(\"span\"+currentId).innerHTML = log.substring(0, log.length * framePercent / 100);\n");
      out.write("\t\t\t\t\tvar logEl = document.getElementById(\"log\");\n");
      out.write("\t\t\t\t\tlogEl.scrollTop = logEl.scrollHeight;\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction GetXmlHttpObject()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tvar xmlHttp=null;\n");
      out.write("\t\t\t\ttry\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\t// Firefox, Opera 8.0+, Safari\n");
      out.write("\t\t\t\t\txmlHttp=new XMLHttpRequest();\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\tcatch (e)\n");
      out.write("\t\t\t\t{\n");
      out.write("\t\t\t\t\t// Internet Explorer\n");
      out.write("\t\t\t\t\ttry\n");
      out.write("\t\t\t\t\t{\n");
      out.write("\t\t\t\t\t\txmlHttp=new ActiveXObject(\"Msxml2.XMLHTTP\");\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t\t\t\tcatch (e)\n");
      out.write("\t\t\t\t\t{\n");
      out.write("\t\t\t\t\t  \txmlHttp=new ActiveXObject(\"Microsoft.XMLHTTP\");\n");
      out.write("\t\t\t\t\t}\n");
      out.write("\t\t\t\t}\n");
      out.write("\t\t\t\treturn xmlHttp;\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction closeEditorMigrationWarning()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\treturn 'If you navigate away, you will not be able to see the migration progress or the log but the migration will continue running. The log is saved on the SMT server\\'s filesystem.'\n");
      out.write("\t\t\t}\n");
      out.write("\t\t\t\n");
      out.write("\t\t\tfunction closeEditorLinkCheckingWarning()\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\treturn 'If you navigate away, you will not be able to see the link checking progress or the log but the link checking will continue running. The log is saved on the SMT server\\'s filesystem.'\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\tfunction enableButtons(goBack, stopMigration, stopLinkChecker, startOver, startLinkChecker, restartLinkChecker, restartMigration)\n");
      out.write("\t\t\t{\n");
      out.write("\t\t\t\tdocument.getElementById(\"goBack\").style.display=goBack?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"stopMigration\").style.display=stopMigration?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"stopLinkChecker\").style.display=stopLinkChecker?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"startOver\").style.display=startOver?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"startLinkChecker\").style.display=startLinkChecker?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"restartLinkChecker\").style.display=restartLinkChecker?\"\":\"none\";\n");
      out.write("\t\t\t\tdocument.getElementById(\"restartMigration\").style.display=restartMigration?\"\":\"none\";\n");
      out.write("\t\t\t}\n");
      out.write("\n");
      out.write("\t\t\twindow.onbeforeunload = closeEditorMigrationWarning\n");
      out.write("\t\t</script>\n");
      out.write("\t</head>\n");
      out.write("\t<body>\n");
      out.write("\t\t<h1>Serena Migration Tool</h1>\n");
      out.write("\t\t<div class=\"main\">\n");
      out.write("\t\t\t<h2>Migration Started</h2>\n");
      out.write("\t\t\t<h4>");
      if (_jspx_meth_s_005factionerror_005f0(_jspx_page_context))
        return;
      out.write("</h4>\n");
      out.write("\t\t\t<div id=\"log\"></div>\n");
      out.write("\t\t\t<div class=\"progress\">\n");
      out.write("\t\t\t\t<div id=\"progress-bar\">\n");
      out.write("\t\t\t\t\t<div id=\"progress-percent\">0%</div>\n");
      out.write("\t\t\t\t\t&nbsp;\n");
      out.write("\t\t\t\t</div>\n");
      out.write("\t\t\t\t<table class=\"status\" id=\"migration-status\">\n");
      out.write("\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t<td>Created: <span id=\"created\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Skipped: <span id=\"skipped\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Errors: <span id=\"errors\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Aligned: <span id=\"aligned\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Aligning errors: <span id=\"notAligned\">0</span></td>\n");
      out.write("\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t</table>\n");
      out.write("\t\t\t\t<table class=\"status\" id=\"link-checker-status\" style=\"display: none;\">\n");
      out.write("\t\t\t\t\t<tr>\n");
      out.write("\t\t\t\t\t\t<td>Checked: <span id=\"checked\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Errors: <span id=\"checkingErrors\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Correct Links: <span id=\"correctLinks\">0</span></td>\n");
      out.write("\t\t\t\t\t\t<td>Broken Links: <span id=\"brokenLinks\">0</span></td>\n");
      out.write("\t\t\t\t\t</tr>\n");
      out.write("\t\t\t\t</table>\n");
      out.write("\t\t\t</div>\n");
      out.write("\t\t\t<div style=\"text-align: center;\">\n");
      out.write("\t\t\t\t<button onclick=\"window.location='/MigrationSummary';return false;\" id=\"goBack\" style=\"display:none;\">Go Back</button>\n");
      out.write("\t\t\t\t<button onclick=\"callStop();return false;\" id=\"stopMigration\">Stop Migration</button>\n");
      out.write("\t\t\t\t<button onclick=\"callStop();return false;\" id=\"stopLinkChecker\" style=\"display:none;\">Stop Link Checker</button>\n");
      out.write("\t\t\t\t<button onclick=\"window.location='/StartFromBeginning';return false;\" id=\"startOver\">Start From Beginning</button>\n");
      out.write("\t\t\t\t<button onclick=\"startLinkChecker();return false;\" id=\"startLinkChecker\" style=\"display: none;\">Start Link Checker</button>\n");
      out.write("\t\t\t\t<button onclick=\"startLinkChecker();return false;\" id=\"restartLinkChecker\" style=\"display: none;\">Restart Link Checker</button>\n");
      out.write("\t\t\t\t<button onclick=\"restartMigration();return false;\" id=\"restartMigration\" style=\"display: none;\">Restart Migration</button>\n");
      out.write("\t\t\t</div>\t\n");
      out.write("\t\t</div>\n");
      out.write("\t\t<script type=\"text/javascript\">\n");
      out.write("\t\t\t");
      if (_jspx_meth_s_005fif_005f0(_jspx_page_context))
        return;
      out.write("\n");
      out.write("\t\t\t");
      if (_jspx_meth_s_005fif_005f1(_jspx_page_context))
        return;
      out.write("\n");
      out.write("\t\t</script>\n");
      out.write("\t</body>\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }

  private boolean _jspx_meth_s_005fproperty_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  s:property
    org.apache.struts2.views.jsp.PropertyTag _jspx_th_s_005fproperty_005f0 = (org.apache.struts2.views.jsp.PropertyTag) _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.get(org.apache.struts2.views.jsp.PropertyTag.class);
    _jspx_th_s_005fproperty_005f0.setPageContext(_jspx_page_context);
    _jspx_th_s_005fproperty_005f0.setParent(null);
    // /jsps/Migration.jsp(6,32) name = value type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_s_005fproperty_005f0.setValue("time");
    int _jspx_eval_s_005fproperty_005f0 = _jspx_th_s_005fproperty_005f0.doStartTag();
    if (_jspx_th_s_005fproperty_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.reuse(_jspx_th_s_005fproperty_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.reuse(_jspx_th_s_005fproperty_005f0);
    return false;
  }

  private boolean _jspx_meth_s_005fproperty_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  s:property
    org.apache.struts2.views.jsp.PropertyTag _jspx_th_s_005fproperty_005f1 = (org.apache.struts2.views.jsp.PropertyTag) _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.get(org.apache.struts2.views.jsp.PropertyTag.class);
    _jspx_th_s_005fproperty_005f1.setPageContext(_jspx_page_context);
    _jspx_th_s_005fproperty_005f1.setParent(null);
    // /jsps/Migration.jsp(7,61) name = value type = java.lang.String reqTime = false required = false fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_s_005fproperty_005f1.setValue("time");
    int _jspx_eval_s_005fproperty_005f1 = _jspx_th_s_005fproperty_005f1.doStartTag();
    if (_jspx_th_s_005fproperty_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.reuse(_jspx_th_s_005fproperty_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fs_005fproperty_0026_005fvalue_005fnobody.reuse(_jspx_th_s_005fproperty_005f1);
    return false;
  }

  private boolean _jspx_meth_s_005factionerror_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  s:actionerror
    org.apache.struts2.views.jsp.ui.ActionErrorTag _jspx_th_s_005factionerror_005f0 = (org.apache.struts2.views.jsp.ui.ActionErrorTag) _005fjspx_005ftagPool_005fs_005factionerror_005fnobody.get(org.apache.struts2.views.jsp.ui.ActionErrorTag.class);
    _jspx_th_s_005factionerror_005f0.setPageContext(_jspx_page_context);
    _jspx_th_s_005factionerror_005f0.setParent(null);
    int _jspx_eval_s_005factionerror_005f0 = _jspx_th_s_005factionerror_005f0.doStartTag();
    if (_jspx_th_s_005factionerror_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fs_005factionerror_005fnobody.reuse(_jspx_th_s_005factionerror_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fs_005factionerror_005fnobody.reuse(_jspx_th_s_005factionerror_005f0);
    return false;
  }

  private boolean _jspx_meth_s_005fif_005f0(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  s:if
    org.apache.struts2.views.jsp.IfTag _jspx_th_s_005fif_005f0 = (org.apache.struts2.views.jsp.IfTag) _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.get(org.apache.struts2.views.jsp.IfTag.class);
    _jspx_th_s_005fif_005f0.setPageContext(_jspx_page_context);
    _jspx_th_s_005fif_005f0.setParent(null);
    // /jsps/Migration.jsp(300,3) name = test type = java.lang.String reqTime = false required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_s_005fif_005f0.setTest("projectInformation.currentTask=='link-checker'");
    int _jspx_eval_s_005fif_005f0 = _jspx_th_s_005fif_005f0.doStartTag();
    if (_jspx_eval_s_005fif_005f0 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_s_005fif_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_s_005fif_005f0.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_s_005fif_005f0.doInitBody();
      }
      do {
        out.write("switchUIToLinkChecker();");
        int evalDoAfterBody = _jspx_th_s_005fif_005f0.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_s_005fif_005f0 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_s_005fif_005f0.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.reuse(_jspx_th_s_005fif_005f0);
      return true;
    }
    _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.reuse(_jspx_th_s_005fif_005f0);
    return false;
  }

  private boolean _jspx_meth_s_005fif_005f1(PageContext _jspx_page_context)
          throws Throwable {
    PageContext pageContext = _jspx_page_context;
    JspWriter out = _jspx_page_context.getOut();
    //  s:if
    org.apache.struts2.views.jsp.IfTag _jspx_th_s_005fif_005f1 = (org.apache.struts2.views.jsp.IfTag) _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.get(org.apache.struts2.views.jsp.IfTag.class);
    _jspx_th_s_005fif_005f1.setPageContext(_jspx_page_context);
    _jspx_th_s_005fif_005f1.setParent(null);
    // /jsps/Migration.jsp(301,3) name = test type = java.lang.String reqTime = false required = true fragment = false deferredValue = false expectedTypeName = null deferredMethod = false methodSignature = null
    _jspx_th_s_005fif_005f1.setTest("projectInformation.currentTask!='link-checker'");
    int _jspx_eval_s_005fif_005f1 = _jspx_th_s_005fif_005f1.doStartTag();
    if (_jspx_eval_s_005fif_005f1 != javax.servlet.jsp.tagext.Tag.SKIP_BODY) {
      if (_jspx_eval_s_005fif_005f1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.pushBody();
        _jspx_th_s_005fif_005f1.setBodyContent((javax.servlet.jsp.tagext.BodyContent) out);
        _jspx_th_s_005fif_005f1.doInitBody();
      }
      do {
        out.write("sendAjaxRequestForProgress();");
        int evalDoAfterBody = _jspx_th_s_005fif_005f1.doAfterBody();
        if (evalDoAfterBody != javax.servlet.jsp.tagext.BodyTag.EVAL_BODY_AGAIN)
          break;
      } while (true);
      if (_jspx_eval_s_005fif_005f1 != javax.servlet.jsp.tagext.Tag.EVAL_BODY_INCLUDE) {
        out = _jspx_page_context.popBody();
      }
    }
    if (_jspx_th_s_005fif_005f1.doEndTag() == javax.servlet.jsp.tagext.Tag.SKIP_PAGE) {
      _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.reuse(_jspx_th_s_005fif_005f1);
      return true;
    }
    _005fjspx_005ftagPool_005fs_005fif_0026_005ftest.reuse(_jspx_th_s_005fif_005f1);
    return false;
  }
}
